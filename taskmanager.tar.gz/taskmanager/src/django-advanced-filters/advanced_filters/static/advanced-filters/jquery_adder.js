(function($) {
	if (!window.jQuery)	window.jQuery = $;
})(window._jq || jQuery || grp.jQuery);